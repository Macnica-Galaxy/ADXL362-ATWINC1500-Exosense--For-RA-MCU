/*
 * winc15x0.h
 *
 *  Created on: 2021年3月25日
 *      Author: Alvin.Yang
 */

#ifndef WINC1500_WINC15X0_H_
#define WINC1500_WINC15X0_H_

extern volatile uint32_t OneMsCounter;  //  ATWINC15x0
void WINC_Send_End_Callback(void);
void m2m_EintHandler(void);

#endif /* WINC1500_WINC15X0_H_ */
