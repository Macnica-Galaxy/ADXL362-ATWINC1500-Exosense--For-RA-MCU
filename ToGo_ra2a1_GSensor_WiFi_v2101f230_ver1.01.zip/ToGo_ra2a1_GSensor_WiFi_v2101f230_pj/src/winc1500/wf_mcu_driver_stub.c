
//#include "mcc.h"
#include "hal_data.h"
#include "winc1500_api.h"

volatile uint32_t OneMsCounter;
volatile _Bool WINC_Tx_Busy = false;

#if defined(USING_PICTAIL)
void m2mStub_PinSet_CE(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_04, BSP_IO_LEVEL_LOW);
    }
    else
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_04, BSP_IO_LEVEL_HIGH);
    }
}

void m2mStub_PinSet_RESET(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_07, BSP_IO_LEVEL_LOW);
    }
    else
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_07, BSP_IO_LEVEL_HIGH);
    }
}
#endif


void m2mStub_PinSet_SPI_SS(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_09, BSP_IO_LEVEL_LOW);
    }
    else
    {
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_09, BSP_IO_LEVEL_HIGH);
    }
}

uint32_t m2mStub_GetOneMsTimer(void)
{
    return OneMsCounter;
}

void m2mStub_EintEnable(void)
{
    //R_ICU_ExternalIrqEnable(&winc_irq_ctrl);
}

void m2mStub_EintDisable(void)
{
    //R_ICU_ExternalIrqDisable(&winc_irq_ctrl);
}

/*******************************************************************************
  Function:
    void m2mStub_SpiTxRx(void)

  Summary:
    Transmits and receives SPI bytes

  Description:
    Transmits and receives N bytes of SPI data.

  Precondition:
    None

  Parameters:
    p_txBuf - pointer to SPI tx data
    txLen   - number of bytes to Tx
    p_rxBuf - pointer to where SPI rx data will be stored
    rxLen   - number of SPI rx bytes caller wants copied to p_rxBuf

  Returns:
    None

  Remarks:
    Will clock out the larger of txLen or rxLen, and pad if necessary.
 *******************************************************************************/
void m2mStub_SpiTxRx(uint8_t *p_txBuf,
                    uint16_t txLen,
                    uint8_t *p_rxBuf,
                    uint16_t rxLen)
{
    /* total number of byte to clock is whichever is larger, txLen or rxLen */
    WINC_Tx_Busy = true;

    if(txLen >= rxLen)
    {
        R_SPI_Write(&g_spi_ctrl, p_txBuf, txLen, SPI_BIT_WIDTH_8_BITS);
    }
    else
    {
        R_SPI_Read(&g_spi_ctrl, p_rxBuf, rxLen, SPI_BIT_WIDTH_8_BITS);
    }

    while(WINC_Tx_Busy);
}

void SpiInit(void)
{
    // Init Already
}

//  alvin 20210325 mask
//#if defined(M2M_ENABLE_SPI_FLASH)
//void m2m_wifi_console_write_data(uint16_t length, uint8_t *p_buf)
//{
//    uint16_t i;
//
//    for (i = 0; i < length; ++i)
//    {
//        UART2_Write(p_buf[i]);
//    }
//}
//
//uint8_t m2m_wifi_console_read_data(void)
//{
//    return UART2_Read();
//}
//
//bool m2m_wifi_console_is_read_data(void)
//{
//    return (U2STAbits.URXDA == 1);
//}
//#endif // M2M_ENABLE_SPI_FLASH

void WINC_Send_End_Callback(void)
{
    WINC_Tx_Busy = false;
}
