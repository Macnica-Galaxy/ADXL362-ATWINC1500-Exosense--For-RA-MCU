/*******************************************************************************
  File Name:
    winc1500_signal_strength.c

  Summary:
    WINC1500 ExoSite ExoSense Demo.

  Description:
        
    The configuration defines for this demo are: 
        WLAN_SSID             -- AP to connect to
        WLAN_AUTH             -- Security type of the AP
        WLAN_PSK              -- Passphrase if using WPA security
    
    The demo uses this callback function to handle events:
        wifi_cb()
*******************************************************************************/

//DOM-IGNORE-BEGIN
/*==============================================================================
Copyright 2016 Microchip Technology Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

//==============================================================================
// INCLUDES
//==============================================================================
#include "hal_data.h"
#include "winc1500_api.h"
#include "demo_config.h"
#include "wf_common.h"
#include "ADXL362.h"

#if defined(USING_EXOSITE_EXOSENSE)
#include "errno_local.h"
#include "http_client.h"
#include "json.h"

#define EXOSITE_PROVISION_URL                   "https://m21d2g4j50cu80000.m2.exosite.io/provision/activate"
#define EXOSITE_POST_URL                        "https://m21d2g4j50cu80000.m2.exosite.io/onep:v1/stack/alias"
#define EXOSITE_GET_URL                         "https://m21d2g4j50cu80000.m2.exosite.io/timestamp"
#define EXOSITE_EXAMPLE_HTTP_CIK_EXT_HEADER		"X-Exosite-CIK:%s\r\n"
#define EXOSITE_EXAMPLE_HTTP_CONTENT_TYPE		"application/x-www-form-urlencoded; charset=utf-8"
#define WLAN_AUTH          M2M_WIFI_SEC_WPA_PSK // AP Security

// User need to modify 1.device token 2.device id 3.ssid 4.password
//#define DEVICE_TOKEN       "MACNICA_TOKEN"
//#define DEVICE_ID          "id=MACNICA_ID"
//#define WLAN_SSID          "MACNICA_SSID"
//#define WLAN_PSK           "MACNICA_PSW"


#ifndef DEVICE_TOKEN
#error need define Token
#endif
#ifndef DEVICE_ID
#error need define Device_ID
#endif
#ifndef WLAN_SSID
#error need define SSID         // target AP
#endif
#ifndef WLAN_PSK
#error need define Password     // security password
#endif

// State macros
#define SetAppState(state) g_appState = state
#define GetAppState()      g_appState

// application states
typedef enum
{
    APP_STATE_WAIT_FOR_DRIVER_INIT,
    APP_STATE_START,
    APP_STATE_WAIT_FOR_CONNECT_AND_DHCP,
    APP_STATE_WORKING,
    APP_STATE_DONE
} t_AppState;

t_AppState g_appState = APP_STATE_WAIT_FOR_DRIVER_INIT;

/** Instance of Timer module. */
struct sw_timer_module swt_module_inst;

/** Instance of HTTP client module. */
struct http_client_module http_client_module_inst;

static void configure_http_client(void);
static void http_client_callback(struct http_client_module *module_inst, int type, union http_client_data *data);
static void wifi_cb(uint8_t msgType, void *pvMsg);
static void resolve_cb(char *pu8DomainName, uint32_t serverIP); 
static void socket_cb(SOCKET sock, uint8_t message, void *pvMsg);

static uint32_t startTime = 0;
static bool wifiConnected = false;

static bool provisioned = false;    //  alvin 20210514
static bool io_configed = false;
static bool httpRequested = false;
static bool httpResponsed = false;
static uint16_t g_code;

static char g_ssid[] = {WLAN_SSID};
struct http_entity g_http_entity = {0,};



const char* _exosite_example_http_get_contents_type(void *priv_data)
{
	return (const char*)EXOSITE_EXAMPLE_HTTP_CONTENT_TYPE;
}

int _exosite_example_http_get_contents_length(void *priv_data)
{
	return strlen( (char*)priv_data);
}

int _exosite_example_http_read(void *priv_data, char *buffer, uint32_t size, uint32_t written)
{
	int32_t length = 0;
	
	if(priv_data)
	{
		length = strlen( (char*)priv_data);
		memcpy(buffer,(char*)priv_data, length);
	}
	
	return length;
}

void _exosite_example_http_close(void *priv_data)
{
}

struct http_entity * _exosite_example_http_set_default_entity()
{
	memset(&g_http_entity, 0x00, sizeof(struct http_entity));
	g_http_entity.close = _exosite_example_http_close;
	g_http_entity.is_chunked = 0;
	g_http_entity.priv_data = NULL;
	g_http_entity.read = _exosite_example_http_read;
	g_http_entity.get_contents_length = _exosite_example_http_get_contents_length;
	g_http_entity.get_contents_type = _exosite_example_http_get_contents_type;
	
	return &g_http_entity;
}
static uint32_t sent_count=0;

// application state machine called from main()
void ApplicationTask(void)
{
    struct http_entity * entity = _exosite_example_http_set_default_entity();
    volatile char ext_header[100] = {0,};       //  alvin 20210514
    volatile char data[100] = {0,};
    volatile char provision_data[1440] = {0,};
    
    switch (GetAppState())
    {
        case APP_STATE_WAIT_FOR_DRIVER_INIT:
            if (isDriverInitComplete())
            {
                SetAppState(APP_STATE_START);
            }
            break;
        
        case APP_STATE_START:
            registerWifiCallback(wifi_cb);
            registerSocketCallback(socket_cb, resolve_cb);

            configure_http_client();

            m2m_wifi_connect(g_ssid,
                             strlen(WLAN_SSID),
                             WLAN_AUTH,
                             (void *)WLAN_PSK,
                             M2M_WIFI_CH_ALL);
            SetAppState(APP_STATE_WAIT_FOR_CONNECT_AND_DHCP);
            break;
        
        case APP_STATE_WAIT_FOR_CONNECT_AND_DHCP:
            if (wifiConnected)
            {
                entity->priv_data = (void*)DEVICE_ID;
                http_client_send_request(&http_client_module_inst, EXOSITE_PROVISION_URL, HTTP_METHOD_POST, entity, NULL);

                startTime = m2mStub_GetOneMsTimer();
                SetAppState(APP_STATE_WORKING);
            }
            break;
        
        case APP_STATE_WORKING:
            if (m2m_get_elapsed_time(startTime) > 5000)
            {
                startTime = m2mStub_GetOneMsTimer();

                if(provisioned)
                {
                    if(io_configed)     //  alvin 20210514
                    {
                        if(httpResponsed & httpRequested)   //  alvin 20210514
                        {
                            sprintf(ext_header,EXOSITE_EXAMPLE_HTTP_CIK_EXT_HEADER, DEVICE_TOKEN);
                            sprintf(data, "data_in={\"g_x\":%.3f,\"g_y\":%.3f,\"g_z\":%.3f,\"alert\":%u}", AXIS_X_float, AXIS_Y_float, AXIS_Z_float, ADXL362_Alert);     //  alvin 20210519
                            entity->priv_data = (void*)data;
                            http_client_send_request(&http_client_module_inst, EXOSITE_POST_URL, HTTP_METHOD_POST, entity, ext_header);
                            httpRequested = httpResponsed = false;
                            sent_count++;
                            printf("debug: send request %u\r\n", sent_count);  //  alvin 20210504 debug
                        }
                    }
                    else
                    {
                            io_configed = true;

                            sprintf(ext_header,EXOSITE_EXAMPLE_HTTP_CIK_EXT_HEADER, DEVICE_TOKEN);
                            sprintf(provision_data, "config_io=%s", "{\"channels\":{\"g_x\": {\"display_name\": \"Gsensor_X\",\"description\": \"Acceleration X\",\"properties\": {\"data_type\": \"ACCELERATION\",\"primitive_type\": \"NUMERIC\",\"data_unit\": \"STANDARD_GRAVITY\",\"precision\": 3},\"protocol_config\": {\"sample_rate\": 60000,\"report_rate\": 60000,\"timeout\": 360000}},\"g_y\": {\"display_name\": \"Gsensor_Y\",\"description\": \"Acceleration Y\",\"properties\": {\"data_type\": \"ACCELERATION\",\"primitive_type\": \"NUMERIC\",\"data_unit\": \"STANDARD_GRAVITY\",\"precision\": 3},\"protocol_config\": {\"sample_rate\": 60000,\"report_rate\": 60000,\"timeout\": 360000}},\"g_z\": {\"display_name\": \"Gsensor_Z\",\"description\": \"Acceleration Z\",\"properties\": {\"data_type\": \"ACCELERATION\",\"primitive_type\": \"NUMERIC\",\"data_unit\": \"STANDARD_GRAVITY\",\"precision\": 3},\"protocol_config\": {\"sample_rate\": 60000,\"report_rate\": 60000,\"timeout\": 360000}},\"alert\": {\"display_name\": \"Alert Status\",\"description\": \"alert State\",\"properties\": {\"data_type\": \"BOOLEAN\",\"primitive_type\": \"BOOLEAN\"},\"protocol_config\": {\"sample_rate\": 60000,\"report_rate\": 60000,\"report_on_change\": false,\"timeout\": 360000}}}}");    //  alvin 20210517
                            entity->priv_data = (void*)provision_data;
                            http_client_send_request(&http_client_module_inst, EXOSITE_POST_URL, HTTP_METHOD_POST, entity, ext_header);
                            httpRequested = httpResponsed = false;
                            sent_count++;
                    }
                }
                else
                {
                    //  ABOUT PROVISION   //    alvin 20210514
                    provisioned = true;
//                    entity->priv_data = (void*)DEVICE_ID;
//                    http_client_send_request(&http_client_module_inst, EXOSITE_PROVISION_URL, HTTP_METHOD_POST, entity, NULL);
                }
            }
            break;
        
        case APP_STATE_DONE:
            break;
    }
}

static void configure_http_client(void)
{
    struct http_client_config httpc_conf;
    int ret;

    http_client_get_config_defaults(&httpc_conf);

    httpc_conf.recv_buffer_size = 256;
    httpc_conf.timer_inst = &swt_module_inst;
    /* ipinfo.io send json format data if only client is a curl. */
    httpc_conf.user_agent = "curl/7.10.6";

    ret = http_client_init(&http_client_module_inst, &httpc_conf);
    if (ret < 0) 
    {
        printf("HTTP client initialization has failed(%d)\r\n", ret);
        while (1) 
        {
        } /* Loop forever. */
    }

    http_client_register_callback(&http_client_module_inst, http_client_callback);
}
static void http_client_callback(struct http_client_module *module_inst, int type, union http_client_data *data)
{
    switch (type) 
    {
        case HTTP_CLIENT_CALLBACK_SOCK_CONNECTED:
            printf("Http Connected:%u\r\n", sent_count);
            break;

        case HTTP_CLIENT_CALLBACK_REQUESTED:
            printf("Requested:%u\r\n", sent_count);
            httpRequested = true;   //  alvin 20210514
            break;

        case HTTP_CLIENT_CALLBACK_RECV_RESPONSE:
            printf("Received response %u data size %u:%u\r\n",
                    (unsigned int)data->recv_response.response_code,
                    (unsigned int)data->recv_response.content_length,
                    sent_count);
            if (data->recv_response.content != NULL)
            {

                unsigned int i;
                for (i = 0; i < data->recv_response.content_length; i++)
                {
                    if (data->recv_response.content[i] == 0x0a)
                    {
                        printf("%c", 0x0d);  // output CR
                    }
                    printf("%c", data->recv_response.content[i]);
                }
            }
            httpResponsed = true;   //  alvin 20210514
            g_code = (unsigned int)data->recv_response.response_code;
            switch(g_code)  //  alvin 20210514
            {
                case 200:
                    __NOP();
                    break;
                case 204:
                    __NOP();
                    break;
                default:
                    __NOP();
                    break;
            }
            break;

        case HTTP_CLIENT_CALLBACK_DISCONNECTED:
            printf("Disconnected reason:%d:%u\r\n", data->disconnected.reason, sent_count);

            /* If disconnect reason is equals to -ECONNRESET(-104),
             * It means Server was disconnected your connection by the keep alive timeout.
             * This is normal operation.
             */
            break;
    }
}
static void wifi_cb(uint8_t msgType, void *pvMsg)
{
    switch (msgType) {
    case M2M_WIFI_CONN_STATE_CHANGED_EVENT:
    {
        tstrM2mWifiStateChanged *pWifiConnState = (tstrM2mWifiStateChanged *)pvMsg;
        if (pWifiConnState->u8CurrState == M2M_WIFI_CONNECTED) 
        {
            printf("Connected -- starting DHCP client\r\n");
        } 
        else if (pWifiConnState->u8CurrState == M2M_WIFI_DISCONNECTED) 
        {
            wifiConnected = false;
            printf("disconnected -- starting connect again\r\n");
            m2m_wifi_connect((char *)WLAN_SSID,
                             strlen(WLAN_SSID),
                             WLAN_AUTH, 
                             (char *)WLAN_PSK,
                             M2M_WIFI_CH_ALL);
            SetAppState(APP_STATE_WAIT_FOR_CONNECT_AND_DHCP);
        }
        break;
    }

    case M2M_WIFI_IP_ADDRESS_ASSIGNED_EVENT:
    {
        char buf[M2M_INET4_ADDRSTRLEN];  
        // read it from event data,
        tstrM2MIPConfig *p_ipConfig = (tstrM2MIPConfig *)pvMsg;
        // convert binary IP address to string
        inet_ntop4(p_ipConfig->u32StaticIp, buf);
        printf("IP address assigned: %s\r\n", buf);
        wifiConnected = true;
        break;
    }
    
	case M2M_WIFI_RSSI_EVENT:
    {
        /* This message type is triggered by "m2m_wifi_req_curr_rssi()" function. */
    	int8_t *p_rssi = (int8_t *)pvMsg;
    	printf("RSSI for the current connected AP (%d)\r\n", (int8_t)(*p_rssi));
    	break;
    }
    
    default:
    {
        break;
    }
    }
}
static void resolve_cb(char *domain_name, uint32_t server_ip)
{
    http_client_socket_resolve_handler((uint8_t *)domain_name, server_ip);
}
static void socket_cb(SOCKET sock, uint8_t msg_type, void *msg_data)
{
    http_client_socket_event_handler(sock, msg_type, msg_data);
}
#endif
