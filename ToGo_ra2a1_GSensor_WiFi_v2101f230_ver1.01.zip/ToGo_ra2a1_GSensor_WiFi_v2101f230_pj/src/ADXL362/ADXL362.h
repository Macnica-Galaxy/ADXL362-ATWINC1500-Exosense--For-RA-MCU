/*
 * ADXL362.h
 *
 *  Created on: 2021年3月3日
 *      Author: Alvin.Yang
 */

#ifndef ADXL362_ADXL362_H_
#define ADXL362_ADXL362_H_

#define LOW (0)
#define HIGH (1)


/* ------- Register names ------- */

#define XL362_DEVID_AD            0x00
#define XL362_DEVID_MST           0x01
#define XL362_PARTID              0x02
#define XL362_REVID               0x03
#define XL362_XDATA               0x08
#define XL362_YDATA               0x09
#define XL362_ZDATA               0x0A
#define XL362_STATUS              0x0B
#define XL362_FIFO_ENTRIES_L      0x0C
#define XL362_FIFO_ENTRIES_H      0x0D
#define XL362_XDATA_L             0x0E
#define XL362_XDATA_H             0x0F
#define XL362_YDATA_L             0x10
#define XL362_YDATA_H             0x11
#define XL362_ZDATA_L             0x12
#define XL362_ZDATA_H             0x13
#define XL362_TEMP_L              0x14
#define XL362_TEMP_H              0x15
#define XL362_SOFT_RESET          0x1F
#define XL362_THRESH_ACT_L        0x20
#define XL362_THRESH_ACT_H        0x21
#define XL362_TIME_ACT            0x22
#define XL362_THRESH_INACT_L      0x23
#define XL362_THRESH_INACT_H      0x24
#define XL362_TIME_INACT_L        0x25
#define XL362_TIME_INACT_H        0x26
#define XL362_ACT_INACT_CTL       0x27
#define XL362_FIFO_CONTROL        0x28
#define XL362_FIFO_SAMPLES        0x29
#define XL362_INTMAP1             0x2A
#define XL362_INTMAP2             0x2B
#define XL362_FILTER_CTL          0x2C
#define XL362_POWER_CTL           0x2D
#define XL362_SELF_TEST           0x2E

uint8_t ADXL362_Init(void);
void ADXL362_CS(_Bool level);
void ADXL362_Send_End_Callback(void);
void ADXL362_Delay_ms(uint32_t ms);
void ADXL362_RegisterWrite(uint8_t Address, uint8_t SendValue);
void ADXL362_BurstRead(uint8_t Address, uint8_t NumberofRegisters, uint8_t *buffer);
void ADXL362_BurstWrite(uint8_t Address, uint8_t NumberofRegisters, uint8_t *buffer);
uint8_t ADXL362_RegisterRead(uint8_t Address);
void ADXL362_ReadDeviceID(uint8_t * buffer);
uint8_t ADXL362_ReadAXIS_XYZ(void);

typedef union
{
    uint8_t AXIS_DataBuf[6];
    struct
    {
        uint16_t AXIS_X_Data;
        uint16_t AXIS_Y_Data;
        uint16_t AXIS_Z_Data;
    } XYZ; // 6 bytes
}AXIS_DATA;

extern AXIS_DATA AXIS_Data;
extern uint8_t ADXL362_Tx_buffer[100];
extern uint8_t ADXL362_Rx_buffer[100];
extern volatile _Bool ADXL362_Tx_Busy;
extern float AXIS_X_float;
extern float AXIS_Y_float;
extern float AXIS_Z_float;
extern _Bool ADXL362_Alert;
#endif /* ADXL362_ADXL362_H_ */
