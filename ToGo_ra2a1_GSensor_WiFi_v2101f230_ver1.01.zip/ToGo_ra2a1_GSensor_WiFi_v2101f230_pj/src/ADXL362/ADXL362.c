
#include "hal_data.h"
#include "ADXL362.h"

void printmsg(char *format,...);        //  alvin 20210519

volatile _Bool ADXL362_Tx_Busy = false;
uint8_t ADXL362_Tx_buffer[100];
uint8_t ADXL362_Rx_buffer[100];
float AXIS_X_float; //  alvin 20210519
float AXIS_Y_float;
float AXIS_Z_float;
_Bool ADXL362_Alert = false;

AXIS_DATA AXIS_Data;

uint8_t ADXL362_Init(void)
{
    ADXL362_Tx_buffer[0] = 0x0a;                   //Write command
    ADXL362_Tx_buffer[1] = 0x1f;                   //Start address
    ADXL362_Tx_buffer[2] = 0x52;                   //Soft Reset

    ADXL362_CS(LOW);
    ADXL362_Tx_Busy = true;
    R_SPI_Write(&g_spi_ctrl, &ADXL362_Tx_buffer, 3, SPI_BIT_WIDTH_8_BITS);   //  User HAL
    while(ADXL362_Tx_Busy);
    ADXL362_CS(HIGH);
    ADXL362_Delay_ms(1);

    if(ADXL362_RegisterRead(XL362_DEVID_AD) == 0xAD)
    {
        ADXL362_RegisterWrite(XL362_FILTER_CTL, 0x93);

        ADXL362_RegisterWrite(XL362_POWER_CTL, 0x02);

        ADXL362_Delay_ms(100);

        ADXL362_BurstRead(XL362_XDATA_L, 6, AXIS_Data.AXIS_DataBuf);    //Read three axis acceleration data

        return 0;
    }

    return 1;
}

void ADXL362_CS(_Bool level)
{

    if(level == LOW)
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_02, BSP_IO_LEVEL_LOW);     //  User HAL
    else
        R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_02, BSP_IO_LEVEL_HIGH);    //  User HAL
}

// Implement to User HAL
void ADXL362_Send_End_Callback(void)
{
    ADXL362_Tx_Busy = false;
}

void ADXL362_Delay_ms(uint32_t ms)
{
   R_BSP_SoftwareDelay(ms, BSP_DELAY_UNITS_MILLISECONDS);   //  User HAL
}


void ADXL362_RegisterWrite(uint8_t Address, uint8_t SendValue)
{
    uint8_t SendTemp[3];

    SendTemp[0] = 0x0A;                 //0x0A: write register
    SendTemp[1] = Address;              //address byte
    SendTemp[2] = SendValue;

    ADXL362_Tx_Busy = true;
    ADXL362_CS(LOW);                    //CS down

    R_SPI_Write(&g_spi_ctrl, &SendTemp, 3, SPI_BIT_WIDTH_8_BITS);   //  User HAL
    while(ADXL362_Tx_Busy);
    ADXL362_CS(HIGH);                   //CS up
}

uint8_t ADXL362_RegisterRead(uint8_t Address)
{
    uint8_t SendTemp[3];
    uint8_t ReceiveTemp[3];
    uint8_t ReceiveValue;


    SendTemp[0] = 0x0B;                 //0x0B: read register command
    SendTemp[1] = Address;              //address byte
    SendTemp[2] = 0;

    ADXL362_Tx_Busy = true;
    ADXL362_CS(LOW);                    //CS down

    R_SPI_WriteRead(&g_spi_ctrl, &SendTemp, &ReceiveTemp, 3, SPI_BIT_WIDTH_8_BITS);
    while(ADXL362_Tx_Busy);
    ADXL362_CS(HIGH);                   //CS up
    ReceiveValue = ReceiveTemp[2];

    return(ReceiveValue);
}

void ADXL362_BurstRead(uint8_t Address, uint8_t NumberofRegisters, uint8_t *buffer)
{
    uint32_t len = (uint8_t)NumberofRegisters + 2;
    uint8_t RegisterData[100];

    memset(ADXL362_Tx_buffer, 0, sizeof(ADXL362_Tx_buffer));


    ADXL362_Tx_buffer[0] = 0x0B;            //0x0B: read register
    ADXL362_Tx_buffer[1] = Address;         //address byte

    ADXL362_Tx_Busy = true;
    ADXL362_CS(LOW);         //CS down

    R_SPI_WriteRead(&g_spi_ctrl, &ADXL362_Tx_buffer, &RegisterData, len, SPI_BIT_WIDTH_8_BITS);
    while(ADXL362_Tx_Busy);
    ADXL362_CS(HIGH);                   //CS up

    memcpy(buffer, RegisterData+2, NumberofRegisters);
}

void ADXL362_BurstWrite(uint8_t Address, uint8_t NumberofRegisters, uint8_t *buffer)
{
    uint32_t len = (uint8_t)NumberofRegisters + 2;

    ADXL362_Tx_Busy = true;
    ADXL362_CS(LOW);         //CS down

    R_SPI_Write(&g_spi_ctrl, buffer, len, SPI_BIT_WIDTH_8_BITS);   //  User HAL
    while(ADXL362_Tx_Busy);
    ADXL362_CS(HIGH);                   //CS up
}

void ADXL362_ReadDeviceID(uint8_t * buffer)
{
    ADXL362_BurstRead(XL362_DEVID_AD,  4, buffer);
    __NOP();
}

uint8_t ADXL362_ReadAXIS_XYZ(void)
{
    uint16_t AXIS_XYZ_Temp = 0;

    if(ADXL362_RegisterRead(XL362_DEVID_AD) == 0xAD)
    {
        ADXL362_BurstRead(XL362_XDATA_L, 6, AXIS_Data.AXIS_DataBuf);    //Read three axis acceleration data
        ADXL362_Alert = false;  //  Just an example ; User can verify

        if(AXIS_Data.XYZ.AXIS_X_Data & 0x800)
        {
            AXIS_XYZ_Temp = (AXIS_Data.XYZ.AXIS_X_Data & 0x7FF);
            AXIS_XYZ_Temp ^= 0x7FF;
            AXIS_X_float = (float)AXIS_XYZ_Temp;
            AXIS_X_float /= 1000;
            AXIS_X_float *= (-1);
        }
        else
        {
            AXIS_X_float = (float)(AXIS_Data.XYZ.AXIS_X_Data & 0x7FF);
            AXIS_X_float /= 1000;
        }

        if(AXIS_Data.XYZ.AXIS_Y_Data & 0x800)
        {
            AXIS_XYZ_Temp = (AXIS_Data.XYZ.AXIS_Y_Data & 0x7FF);
            AXIS_XYZ_Temp ^= 0x7FF;
            AXIS_Y_float = (float)AXIS_XYZ_Temp;
            AXIS_Y_float /= 1000;
            AXIS_Y_float *= (-1);
        }
        else
        {
            AXIS_Y_float = (float)(AXIS_Data.XYZ.AXIS_Y_Data & 0x7FF);
            AXIS_Y_float /= 1000;
        }

        if(AXIS_Data.XYZ.AXIS_Z_Data & 0x800)
        {
            AXIS_XYZ_Temp = (AXIS_Data.XYZ.AXIS_Z_Data & 0x7FF);
            AXIS_XYZ_Temp ^= 0x7FF;
            AXIS_Z_float = (float)AXIS_XYZ_Temp;
            AXIS_Z_float /= 1000;
            AXIS_Z_float *= (-1);
            ADXL362_Alert = true;   //  Just an example ; User can verify
        }
        else
        {
            AXIS_Z_float = (float)(AXIS_Data.XYZ.AXIS_Z_Data & 0x7FF);
            AXIS_Z_float /= 1000;
        }


        return 0;

    }

    return 1;
}
